import pandas as pd

# from olapy.core.mdx.executor.execute import MdxEngine
# executor = MdxEngine()
from olapy.core.services.xmla_lib import run_xmla

# config = {'cube': 'sales','request_type': 'DISCOVER_PROPERTIES','properties': {},'restrictions': {'PropertyName': 'ServerName'},'mdx_query': None}
# dataframes = {'Facts' : pd.read_csv("/home/moddoy/olapy-data/cubes/sales/Facts.csv"),
# 'Product':pd.read_csv("/home/moddoy/olapy-data/cubes/sales/Product.csv"),
# 'Geography':pd.read_csv("/home/moddoy/olapy-data/cubes/sales/Geography.csv")
# }


# au lieu de xmla request, un dict (apres on va changer ça selon onlyoffice, jIo... )
config = {'cube': 'Activity Export.Jan.Fev.2018',
          'properties': {'AxisFormat': 'TupleFormat', 'Format': 'Multidimensional', 'Content': 'SchemaData',
                         'Catalog': 'Activity Export.Jan.Fev.2018',
                         'LocaleIdentifier': '1033', 'Timeout': '0'},
          'mdx_query': """SELECT  FROM [Activity Export.Jan.Fev.2018] WHERE ([Measures].[Price]) CELL PROPERTIES VALUE,FORMAT_STRING, LANGUAGE, BACK_COLOR, FORE_COLOR, FONT_FLAGS"""}
# les dataframes doivent etre passé en params ( on n'utilise plus le loader d'olapy)
dataframes = {
    'Facts': pd.read_csv("/home/moddoy/olapy-data/cubes/Activity Export.Jan.Fev.2018/Facts.csv", sep=';'),
    'Accounts': pd.read_csv("/home/moddoy/olapy-data/cubes/Activity Export.Jan.Fev.2018/Accounts.csv", sep=';'),
    # 'Client': pd.read_csv("/home/moddoy/olapy-data/cubes/Activity Export.Jan.Fev.2018/Client.csv",sep=';'),
    'Date': pd.read_csv("/home/moddoy/olapy-data/cubes/Activity Export.Jan.Fev.2018/Date.csv", sep=';'),
    'Product': pd.read_csv("/home/moddoy/olapy-data/cubes/Activity Export.Jan.Fev.2018/Product.csv", sep=';'),
    'Sales': pd.read_csv("/home/moddoy/olapy-data/cubes/Activity Export.Jan.Fev.2018/Sales.csv", sep=';'),
    # 'Sender': pd.read_csv("/home/moddoy/olapy-data/cubes/Activity Export.Jan.Fev.2018/sender.csv",sep=';'),
    'Trade': pd.read_csv("/home/moddoy/olapy-data/cubes/Activity Export.Jan.Fev.2018/Trade.csv", sep=';'),
    # 'Delivery': pd.read_csv("/home/moddoy/olapy-data/cubes/Activity Export.Jan.Fev.2018/Delivery.csv",sep=';')
}
print(run_xmla(xmla_config=config, dataframes=dataframes))  # donne une response xmla

# run_xmla(xmla_config=config,dataframes=dataframes)
# import pandas as pd
#
# from olapy.core.services.xmla_lib import run_xmla
# # au lieu de xmla request, un dict (apres on va changer ça selon onlyoffice, jIo... )
# config = {'cube': 'Activity Export.Jan.Fev.2018','properties': {'AxisFormat': 'TupleFormat','Format': 'Multidimensional','Content': 'SchemaData','Catalog': 'Activity Export.Jan.Fev.2018',
#                                                                 'LocaleIdentifier': '1033','Timeout': '0'},
#           'mdx_query': """SELECT  FROM [Activity Export.Jan.Fev.2018] WHERE ([Measures].[Price]) CELL PROPERTIES VALUE,FORMAT_STRING, LANGUAGE, BACK_COLOR, FORE_COLOR, FONT_FLAGS"""}
# # les dataframes doivent etre passé en params ( on n'utilise plus le loader d'olapy)
# dataframes = {
#   'Facts': pd.read_csv("olapy-data/cubes/Activity Export.Jan.Fev.2018/Facts.csv", sep=';'),
#   'Accounts': pd.read_csv("olapy-data/cubes/Activity Export.Jan.Fev.2018/Accounts.csv", sep=';'),
#   # 'Client': pd.read_csv("olapy-data/cubes/Activity Export.Jan.Fev.2018/Client.csv",sep=';'),
#   'Date': pd.read_csv("olapy-data/cubes/Activity Export.Jan.Fev.2018/Date.csv", sep=';'),
#   'Product': pd.read_csv("olapy-data/cubes/Activity Export.Jan.Fev.2018/Product.csv", sep=';'),
#   'Sales': pd.read_csv("olapy-data/cubes/Activity Export.Jan.Fev.2018/Sales.csv", sep=';'),
#   # 'Sender': pd.read_csv("olapy-data/cubes/Activity Export.Jan.Fev.2018/sender.csv",sep=';'),
#   'Trade': pd.read_csv("olapy-data/cubes/Activity Export.Jan.Fev.2018/Trade.csv", sep=';'),
#   # 'Delivery': pd.read_csv("olapy-data/cubes/Activity Export.Jan.Fev.2018/Delivery.csv",sep=';')
# }
# run_xmla(xmla_config=config,dataframes=dataframes) # donne une response xmla
