import requests

url = "http://freegeoip.net/json/{}".format("197.26.169.22")
response = requests.get(url)
print (response.json())
