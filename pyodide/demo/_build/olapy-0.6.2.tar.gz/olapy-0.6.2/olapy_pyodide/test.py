from olapy.core.services.xmla_lib import run_xmla

if __name__ == '__main__':
    config1 = {
        'cube': 'sales',
        'request_type': 'DISCOVER_PROPERTIES',
        'properties': {
        },
        'restrictions': {
            'PropertyName': 'ServerName'
        },
        'mdx_query': None
    }

    config2 = {
        'cube': 'Activity Export.Jan.Fev.2018',
        'properties': {
            'AxisFormat': 'TupleFormat',
            'Format': 'Multidimensional',
            'Content': 'SchemaData',
            'Catalog': 'Activity Export.Jan.Fev.2018',
            'LocaleIdentifier': '1033',
            'Timeout': '0'
        },
        'mdx_query': """SELECT  FROM [Activity Export.Jan.Fev.2018] WHERE ([Measures].[Price]) CELL PROPERTIES VALUE,
         FORMAT_STRING, LANGUAGE, BACK_COLOR, FORE_COLOR, FONT_FLAGS"""
    }

    xmla_response = run_xmla(config1)
    print(xmla_response)

    xmla_response = run_xmla(config2)
    print(xmla_response)
