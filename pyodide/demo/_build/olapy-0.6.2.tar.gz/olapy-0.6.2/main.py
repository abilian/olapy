from olapy.core.mdx.executor.execute import MdxEngine
from olapy.core.services.models import DiscoverRequest, Restriction, Property, Restrictionlist, Propertieslist
from olapy.core.services.xmla import XmlaProviderService
from olapy.core.services.xmla_discover_tools import XmlaTools


def main():
    # mdx_engine = MdxEngine()

    mdx_engine = MdxEngine()
    xmla_discover_tools = XmlaTools(mdx_engine)
    xmla_discover_tools.change_catalogue('sales')

    xmla_tools = XmlaProviderService()

    # request = DiscoverRequest(
    #     Restrictions=Restrictions(RestrictionList=Restriction(PropertyName=u'DbpropMsmdSubqueries')),
    #     RequestType=u'DISCOVER_PROPERTIES', Properties=Properties(PropertyList=Property()))
    # xmla_tools.Discover()
    request = DiscoverRequest()

    restriction = Restriction(PropertyName=u'DbpropMsmdSubqueries')
    restrictionlist = Restrictionlist(RestrictionList=restriction)
    request.Restrictions = restrictionlist
    # request.Restrictions.RestrictionList = Restriction(PropertyName=u'DbpropMsmdSubqueries')
    request.RequestType = 'DISCOVER_PROPERTIES'
    property = Property()
    propertieslist = Propertieslist(PropertyList=property)
    request.Properties = propertieslist

    print(xmla_tools.Discover(request, xmla_discover_tools))


if __name__ == '__main__':
    main()
