# -*- encoding: utf8 -*-
from olapy.core.mdx.executor.execute import MdxEngine
from olapy.core.services import xmla
from olapy.core.mdx.executor.MdxEngine import execute_mdx
MdxEngine()
# query = """
# SELECT NON EMPTY Hierarchize(AddCalculatedMembers(DrilldownMember({{[Demande].[Demande].[type_demande].Members}}, {[Demande].[Demande].[type_demande].[Déclaration d´invention]}))) DIMENSION PROPERTIES PARENT_UNIQUE_NAME,HIERARCHY_UNIQUE_NAME ON COLUMNS  FROM [labster_olapy] CELL PROPERTIES VALUE, FORMAT_STRING, LANGUAGE, BACK_COLOR, FORE_COLOR, FONT_FLAGS
# """
# query = """
# SELECT NON EMPTY Hierarchize(AddCalculatedMembers(DrilldownMember({{DrilldownMember({{[Organisation].[Organisation].[Pole].Members}}, {[Organisation].[Organisation].[Pole].[1 - Modélisation et ingénierie],[Organisation].[Organisation].[Pole].[2 - Energie, matiére et univers],[Organisation].[Organisation].[Pole].[3 - Terre vivante et environnement],[Organisation].[Organisation].[Pole].[4 - Vie et santé]})}}, {[Organisation].[Organisation].[Ufr].[1 - Modélisation et ingénierie].[UFR Faculte De Mathematiques],[Organisation].[Organisation].[Ufr].[1 - Modélisation et ingénierie].[UFR Ingenierie],[Organisation].[Organisation].[Ufr].[2 - Energie, matiére et univers].[UFR Chimie],[Organisation].[Organisation].[Ufr].[2 - Energie, matiére et univers].[UFR Faculte De Physique],[Organisation].[Organisation].[Ufr].[3 - Terre vivante et environnement].[Observatoire Oceanologique De Banyuls],[Organisation].[Organisation].[Ufr].[3 - Terre vivante et environnement].[Observatoire Oceanologique De Villefranche],[Organisation].[Organisation].[Ufr].[3 - Terre vivante et environnement].[UFR Terre, Environnement, Biodiversite],[Organisation].[Organisation].[Ufr].[4 - Vie et santé].[UFR Faculte De Medecine Pierre Et Marie Curie],[Organisation].[Organisation].[Ufr].[4 - Vie et santé].[UFR Sciences De La Vie]}))) DIMENSION PROPERTIES PARENT_UNIQUE_NAME,HIERARCHY_UNIQUE_NAME ON COLUMNS  FROM [labster_olapy] CELL PROPERTIES VALUE, FORMAT_STRING, LANGUAGE, BACK_COLOR, FORE_COLOR, FONT_FLAGS
# """
# query = """
# SELECT NON EMPTY CrossJoin(Hierarchize(AddCalculatedMembers({[Organisation].[Organisation].[Pole].Members})), Hierarchize(AddCalculatedMembers({[Demande].[Demande].[type_demande].Members}))) DIMENSION PROPERTIES PARENT_UNIQUE_NAME,HIERARCHY_UNIQUE_NAME ON COLUMNS  FROM [labster_olapy] CELL PROPERTIES VALUE, FORMAT_STRING, LANGUAGE, BACK_COLOR, FORE_COLOR, FONT_FLAGS"""
# query = """
# SELECT NON EMPTY Hierarchize(AddCalculatedMembers(DrilldownMember({{DrilldownMember({{[Organisation].[Organisation].[Pole].Members}}, {[Organisation].[Organisation].[Pole].[1 - Modélisation et ingénierie]})}}, {[Organisation].[Organisation].[Ufr].[1 - Modélisation et ingénierie].[UFR Faculte De Mathematiques]}))) DIMENSION PROPERTIES PARENT_UNIQUE_NAME,HIERARCHY_UNIQUE_NAME ON COLUMNS  FROM [labster_olapy] CELL PROPERTIES VALUE, FORMAT_STRING, LANGUAGE, BACK_COLOR, FORE_COLOR, FONT_FLAGS
# """
query = """
SELECT NON EMPTY Hierarchize(AddCalculatedMembers(DrilldownMember({{
[Organisation].[Organisation].[Pole].Members}}, {
[Organisation].[Organisation].[Pole].[1 - Modélisation et ingénierie]}))) DIMENSION PROPERTIES PARENT_UNIQUE_NAME,HIERARCHY_UNIQUE_NAME ON COLUMNS  FROM [labster_olapy] CELL PROPERTIES VALUE, FORMAT_STRING, LANGUAGE, BACK_COLOR, FORE_COLOR, FONT_FLAGS
"""
executor = MdxEngine()
executor.load_cube('labster_olapy')
print('aaaaaaaaaa')
print(executor.execute_mdx(query)['result'])
