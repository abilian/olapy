
# executor = MdxEngine()
import os

# from olapy.core.services.xmla_lib import run_xmla
from olapy.core.services.xmla_lib import xmla_lib

a =   os.listdir('/home/moddoy/mailfacebook')
run_xmla()
